
<div class="footer">
	<div class="footer-inner">
		<div class="footer-content">
			<div class="fcred"><div id="copyright">Copyright © 2018 "<a href="http://godzillagaming.in/">Godzilla Gamingo/</a>" All Coding Right Reserved by - "<a href="http://www.RegattaSolution.com">Regatta Group</a>"</div><div id="credits">Designed &amp; Developed by "<a href="http://www.RegattaTechnologies.com">Regatta Technologies</a>".</div></div>
		</div>
	</div>
</div>

