<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta charset="utf-8" />
	<title>Dashboard - Godzilla Gaming </title>

	<meta name="description" content="overview &amp; stats" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

	<!-- bootstrap & fontawesome -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/bootstrap.min.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/font-awesome/4.5.0/css/font-awesome.min.css" />

	<!-- page specific plugin styles -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/jquery-ui.custom.min.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/chosen.min.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/bootstrap-datepicker.min.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/bootstrap-timepicker.min.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/daterangepicker.min.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/bootstrap-datetimepicker.min.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/bootstrap-colorpicker.min.css" />
	<!-- text fonts -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/fonts.googleapis.com.css" />
	<!-- custom css open -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/custom/style7e45d5.css" />
	<!-- custom css close  -->
	<!-- ace styles -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/ace-skins.min.css" />
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/ace-rtl.min.css" />

<script src="<?php echo base_url(); ?>assets/assets/js/ace-extra.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/bootstrap-datepicker.min.js"></script>
</head>
<body class="skin-2">
	<div id="navbar" class="navbar navbar-default ace-save-state">
		<div class="navbar-container ace-save-state" id="navbar-container">
			<button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
				<span class="sr-only">Toggle sidebar</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<div class="navbar-header pull-left">
				<a href="Dashboard" class="navbar-brand">
					<small>
						<h4>Godzilla Gaming </h4>
					</small>
				</a>
			</div>
			<div class="navbar-buttons navbar-header pull-right" role="navigation">
				<ul class="nav ace-nav">

					<li class="light-blue dropdown-modal">
						<a data-toggle="dropdown" href="#" class="dropdown-toggle">
							<img class="nav-user-photo" src="<?php echo base_url(); ?>assets/assets/images/avatars/avatar5.png" alt="Jason's Photo" />
							<span class="user-info">
								<!-- <small> Welcome </small><?php echo $this->session->userdata('user'); ?> -->
								<small> Welcome </small><?php echo $this->session->userdata('user'); ?></span>
							<i class="ace-icon fa fa-caret-down"></i>
						</a>
						<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
							<li>
								<a href="">
									<i class="glyphicon glyphicon-th"></i>
									Change Password
								</a>
							</li>
							<li class="divider"></li>
							<li>
								<a href="<?php echo site_url('Admin_login/logout') ?>">
									<i class="ace-icon fa fa-power-off"></i>
									Logout
								</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</div><!-- /.navbar-container -->
	</div>
	<div class="main-container ace-save-state" id="main-container">
		<script type="text/javascript">
			try{ace.settings.loadState('main-container')}catch(e){}
		</script>
		<div id="sidebar" class="sidebar responsive ace-save-state">
			<script type="text/javascript">
				try{ace.settings.loadState('sidebar')}catch(e){}
			</script>

			<div class="sidebar-shortcuts" id="sidebar-shortcuts">
				<div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
					<button class="btn btn-white btn-pink">
						<i class="ace-icon fa fa-signal white"></i>
					</button>
					<button class="btn btn-white btn-pink">
						<i class="ace-icon fa fa-pencil white"></i>
					</button>
					<button class="btn btn-white btn-pink">
						<i class="ace-icon fa fa-users white"></i>
					</button>
					<button class="btn btn-white btn-pink">
						<i class="ace-icon fa fa-cogs white"></i>
					</button>
				</div>
				<div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
					<span class="btn btn-white btn-pink"></span>
					<span class="btn btn-white btn-pink"></span>
					<span class="btn btn-white btn-pink"></span>
					<span class="btn btn-white btn-pink"></span>
				</div>
			</div>
			<div class="desh-img2"><a href="<?php echo site_url('Admin/Dashboard') ?>"> <img src="<?php echo base_url(); ?>assets/assets/images/god-cc.png"></a></div>
			<!-- Sidebar Menus Open-->
			<ul class="nav nav-list">
				<li class="active">
					<a href="<?php echo site_url('Admin/Dashboard') ?>">
						<i class="menu-icon fa fa-tachometer"></i>
						<span class="menu-text"> Dashboard </span>
					</a>
					<b class="arrow"></b>
				</li>
				<li class="">
					<a href="#" class="dropdown-toggle">
						<i class="menu-icon fa fa-list"></i>
						<span class="menu-text"> Test </span>
						<b class="arrow fa fa-angle-down"></b>
					</a>
					<b class="arrow"></b>
					<ul class="submenu">
						<li class="">
							<a href="<?php echo site_url('Admin/test_add') ?>">
								<i class="fa fa-chevron-right"></i> Add Test
							</a>
						</li>
							<li class="">
							<a href="<?php echo site_url('Admin/test_table') ?>">
								<i class="fa fa-chevron-right"></i> List Test
							</a>
						</li>
						<!-- *************************** -->
					</ul>
				</li>

				<li class="">
					<a href="#" class="dropdown-toggle">
						<i class="menu-icon fa fa-list"></i>
						<span class="menu-text"> User </span>
						<b class="arrow fa fa-angle-down"></b>
					</a>
					<b class="arrow"></b>
					<ul class="submenu">
						<li class="">
							<a href="<?php echo site_url('Admin/add_user') ?>">
								<i class="fa fa-chevron-right"></i> Add User
							</a>
						</li>
							<li class="">
							<a href="<?php echo site_url('Admin/user_table') ?>">
								<i class="fa fa-chevron-right"></i> User List 
							</a>
						</li>
						<!-- *************************** -->
					</ul>
				</li>
			</ul>
			<!-- Sidebar Menus Close-->

			<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
				<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
			</div>
		</div>
<div class="main-content">
<div class="page-content">
<div class="main-content-inner">
	<div class="breadcrumbs ace-save-state" id="breadcrumbs">
		<ul class="breadcrumb">
			<li><i class="ace-icon fa fa-home home-icon"></i><a href="<?php echo site_url('Admin/Dashboard') ?>">Dashboard</a></li>
			
		</ul><!-- /.breadcrumb -->
	</div>
</div>


