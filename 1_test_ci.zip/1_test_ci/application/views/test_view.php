<?php $this->load->view('header'); ?>

			
  <?php foreach($result_test as $row){ ?>
	<div class="row">
		<div class="col-xs-12">
			<!--PAGE CONTENT BEGINS -->
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="profile-user-info profile-user-info-striped">
					<div class="profile-info-row">
						<div class="profile-info-name"> <th>Title</th> </div>
						<div class="profile-info-value">
							<td><?php echo $row->title; ?></td>
						</div>
					</div>
					<div class="profile-info-row">
						<div class="profile-info-name"> <th>Description</th> </div>
						<div class="profile-info-value">
							<td><?php echo $row->description; ?></td>
						</div>
					</div>
					<div class="profile-info-row">
						<div class="profile-info-name"> <th>Image</th> </div>
						<div class="profile-info-value">
							<img src="<?php echo base_url();?>uploads/<?php echo $row->image ?>" style="width: 100px;">
								  <!-- <?php echo base_url();?>uploads/doctors/<?php echo $list['image'];?> -->
						</div>
					</div>
					
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
		<?php } ?>				
	</div>

<div class="bottom-margin"></div>
<!--[if !IE]> -->
<script src="<?php echo base_url(); ?>assets/assets/js/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/ace-elements.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/ace.min.js"></script>

<!-- inline scripts related to this page -->
<?php $this->load->view('footer'); ?>


