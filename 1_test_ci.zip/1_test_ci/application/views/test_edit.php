<?php $this->load->view('header.php');?>
<!-- Add Staff Open -->
<!DOCTYPE html>
<html lang="en">
<body class="no-skin">
	<!-- Add Staff Open -->
	<div class="row" style="margin-top: 50px;">
		<div class="col-xs-12">
			<div class="col-md-2"></div>
			<div class="col-md-8 border-tune desh-img">
				<a class="btn btn-info" href="<?php echo base_url('Admin/test_table'); ?>" class="ace-icon fa fa-check bigger-110">Details Table List 
				</a>	
				<?php foreach($result_test as $row){echo form_open_multipart('Admin/test_update/'.$row->id); ?>
				
							<input type="hidden" name="id" value="<?php echo $row->id; ?>">
				<!--<form class="form-horizontal" role="form" method="POST" action="">-->
				<div class="col-md-12" style="width: 100%; border-bottom: 1px solid #000;border-top: 1px solid #000; margin-bottom: 10px;"><h4>Edit Details</h4>
				</div>

				<div class="form-group">
					<label class="col-sm-5 control-label no-padding-right" for="form-field-1-1">Title</label>
					<div class="col-sm-7">
						<input type="text" id="form-field-1-1" name="title" value="<?php echo $row->title ?>" class="form-control" required="" />
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-5 control-label no-padding-right" for="form-field-1-1">Description</label>
					<div class="col-sm-7">
						<input type="text" id="form-field-1-1" name="description" value="<?php echo $row->description ?>" class="form-control" required="" />
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-5 control-label no-padding-right" for="form-field-1-1">Test Image </label>
					<div class="col-sm-7">
						<input type="file" name="image" />
						<img src="<?php echo base_url();?>uploads/<?php echo $row->image ?>" style="width: 100px;">
					</div>
				</div>
				 
				<div class="form-group" style="border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; padding-top: 20px; padding-bottom: 20px;">
					<div class="col-sm-5"></div>
					<div class="col-sm-4">
						<div class="input-group">
							<input class="btn btn-info" type="submit" value="Submit" name="tournament" class="ace-icon fa fa-check bigger-110">
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>

				<?php } ?>
			</div>					
		</div>
		<div class="col-md-2"></div>
	</div>

	<!-- Add Staff close -->
	<?php $this->load->view('footer.php');?>
	<!-- PAGE CONTENT ENDS -->
	<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
		<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
	</a>
	<!-- basic scripts -->
	<!--[if !IE]> -->
	<script src="<?php echo base_url(); ?>assets/assets/js/jquery-2.1.4.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/assets/js/jquery-ui.custom.min.js"></script>
	<!-- ace scripts -->
	<script src="<?php echo base_url(); ?>assets/assets/js/ace-elements.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/assets/js/ace.min.js"></script>
	<!-- inline scripts related to this page -->
</body>
</html>