<?php $this->load->view('header');?>
<!-- <?php
session_start();
echo "welcome" .$_SESSION['user_name'];
?> -->
<div class="row">
	<div class="col-md-12 pn-ProductNav">
		<div>
			<table id="dynamic-table" class="table table-striped table-bordered table-hover">
				<div class="left-side">
					<a href="<?php echo site_url('Admin/test_table') ?>" class="btn btn-info">Test  List</a>
				</div>
				<div class="right-side">
					<a href="<?php echo site_url('Admin/test_add') ?>" class="btn btn-primary"> Add Test</a>
				</div>
				<!-- <div class="table-header">" Squad List "</div> -->
				<thead>
					<tr>
						<th style="background: #307ECC!important; color: #fff!important;"> S.No </th>	
						<th style="background: #307ECC!important; color: #fff!important;">User Name</th>
						<th style="background: #307ECC!important; color: #fff!important;">Email</th>		
						<th style="background: #307ECC!important; color: #fff!important;">Mobile</th>		
						<th style="background: #307ECC!important; color: #fff!important;">Profile Image</th>	
						<th style="background: #307ECC!important; color: #fff!important;">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $i=1; foreach($user_result as $row){  ?>
					<tr>
						<!-- <td class="center"><?php echo $row['id']; ?></td> -->	
						<td><?php echo $i++; ?> </td>
						<td><?php echo $row['u_name']; ?></td>	
						<td><?php echo $row['u_email']; ?></td>
						<td><?php echo $row['u_mobile']; ?></td>
						<td style="width: 100px;"><img src="<?php echo base_url();?>uploads/details/<?php echo $row['u_profile'];?>"></td>
						<td>
						<div class="">
							<a href="<?php echo site_url('Admin/user_view/' .$row['u_id']); ?>" target='_blank' class="blue">
								<i class="ace-icon fa fa-search-plus bigger-130"></i>
							</a>
							<a href="<?php echo site_url('Admin/user_edit/' .$row['u_id']); ?>" class="green">
								<i class="ace-icon fa fa-pencil bigger-130"></i>
							</a>
							<a href="<?php echo site_url('Admin/user_delete/' .$row['u_id']); ?>"  class="red">
								<i class="ace-icon fa fa-trash-o bigger-130"onclick="return confirm('Confirm Are you sure to remove this record ?')" ></i>
							</a>
						</div>
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
			<!-- Pagination Section open -->
			<ul class="pagination pull-right">
				<?php echo $this->pagination->create_links(); ?>
			</ul>
			<!-- Pagination Section close -->
		</div>
	</div>
</div>
<div class="bottom-margin"></div>

<!--[if !IE]> -->
<script src="<?php echo base_url(); ?>assets/assets/js/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/ace-elements.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/ace.min.js"></script>
<!-- inline scripts related to this page -->

<?php $this->load->view('footer');?>