<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php $this->load->view('header');?>
<div class="row">
	<div class="prop" style="text-align: center;">
		<h3>Godzilla Gaming </h3>
	</div>
	<div class="col-md-12">
		<div class="desh-img"><img src="<?php echo base_url(); ?>assets/assets/images/dashboard.jpg" style="width: 100px;border: 5px solid;"></div>
		<div class="desh-img"><img src="<?php echo base_url(); ?>assets/assets/images/god-cc.png"></div>

	</div>
<div class="col-md-12">
<!-- First Step Start -->	
		<div class="col-md-3 col-sm-6 col-xs-12" style="margin-bottom:20px;">
		<div class="info-box bg-aqua reportsDiv" style=" background-color: #00c0ef !important;color: #fff !important;">
			
			<span class="info-box-icon"><i class="fa fa-users"></i></span>
			<div class="info-box-content">
				<a href="view_squad_leader.php">
				<span class="info-box-text ng-binding">
					<div class="txt1"> Squad Leader</div>
<!-- 
<?php 
$sql=("SELECT count(id) AS total FROM property ");
$result=mysqli_query($conn,$sql);
$values=mysqli_fetch_array($result);
$num_rows=$values['total'];
echo $num_rows;
 ?>
-->
				<span class="progress-description ng-binding txt2">View All</span>
				</span>
				</a>
				</div><!-- /.info-box-content -->
			
			</div><!-- /.info-box -->
		</div>

		<div class="col-md-3 col-sm-6 col-xs-12" style="margin-bottom:20px;">
			<div class="info-box bg-yellow reportsDiv" style=" background-color:#f39c12 !important;color: #fff !important;">
				<span class="info-box-icon"><i class="fa fa-user"></i></span>
				<div class="info-box-content">
				<a href="view_squad.php">
				<span class="info-box-text ng-binding">
					<div class="txt1"> Squad</div>
					<!-- <?php 
					$sql=("SELECT count(id) AS total FROM property WHERE purpose='sale'");
					$result=mysqli_query($conn,$sql);
					$values=mysqli_fetch_array($result);
					$num_rows=$values['total'];
					echo $num_rows;
					?> -->
					<span class="progress-description ng-binding">View All</span>
				</span>
				</a>
				</div><!-- /.info-box-content -->
			</div><!-- /.info-box -->
		</div>

		<div class="col-md-3 col-sm-6 col-xs-12" style="margin-bottom:20px;">
			<div class="info-box bg-green reportsDiv" style=" background-color:#00a65a !important;color: #fff !important;">
				<span class="info-box-icon"><i class="fa fa-user"></i></span>
				<div class="info-box-content">
				<a href="view_tournament.php">
				<span class="info-box-text ng-binding">
					<div class="txt1">Tournament</div>
					<!-- <?php 
					$sql=("SELECT count(id) AS total FROM property WHERE purpose='Rent Par Dene Wale'");
					$result=mysqli_query($conn,$sql);
					$values=mysqli_fetch_array($result);
					$num_rows=$values['total'];
					echo $num_rows;
					?> -->
					<span class="progress-description ng-binding">View All</span>
				</span>
			</a>
				</div><!-- /.info-box-content -->
			</div><!-- /.info-box -->
		</div>

		<div class="col-md-3 col-sm-6 col-xs-12" style="margin-bottom:20px;">
			<div class="info-box bg-green reportsDiv" style=" background-color:#00c0ef !important;color: #fff !important;">
				<span class="info-box-icon"><i class="fa fa-user"></i></span>
				<div class="info-box-content">
				<a href="view_tournament_registration.php">
				<span class="info-box-text ng-binding">
					<div class="txt1"> Registration</div>
					<!-- <?php 
					$sql=("SELECT count(id) AS total FROM property WHERE purpose='Rent Par Lene Wale'");
					$result=mysqli_query($conn,$sql);
					$values=mysqli_fetch_array($result);
					$num_rows=$values['total'];
					echo $num_rows;
					?> -->
					<span class="progress-description ng-binding">View All</span>
				</span>
			</a>
				</div><!-- /.info-box-content -->
			</div><!-- /.info-box -->
		</div>
		</div>
		<div class="col-md-12">
<!-- First Step close -->
<!-- Second Step open -->
<div class="col-md-4"></div>
		<div class="col-md-4 col-sm-6 col-xs-12" style="margin-bottom:20px;">
			<div class="info-box bg-red reportsDiv" style=" background-color:#CC0000 !important;color: #fff !important;">
				<span class="info-box-icon"><i class="fa fa-user"></i></span>
				<div class="info-box-content">
				<a href="live_stream_url.php">
				<span class="info-box-text ng-binding">
					<div class="txt1"> Live Stream Url</div>
					<!-- <?php 
					$sql=("SELECT count(id) AS total FROM property WHERE purpose='purchase'");
					$result=mysqli_query($conn,$sql);
					$values=mysqli_fetch_array($result);
					$num_rows=$values['total'];
					echo $num_rows;
					?> -->
					<span class="progress-description ng-binding">View All</span>
				</span>
			</a>
				</div><!-- /.info-box-content -->
			</div><!-- /.info-box -->
		</div>
<div class="col-md-4"></div>
</div>
<!-- Third Step close -->

<!-- PAGE CONTENT ENDS -->
</div><!-- /.col -->


<?php $this->load->view('footer');?>
<!-- End footer -->
<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
	<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
</a>
</div><!-- /.main-container -->
<script src="<?php echo base_url(); ?>assets/assets/js/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/jquery-ui.custom.min.js"></script>
<!-- ace scripts -->
<script src="<?php echo base_url(); ?>assets/assets/js/ace-elements.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/ace.min.js"></script>

</body>
</html>





