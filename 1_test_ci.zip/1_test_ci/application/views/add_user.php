<?php  $this->load->view('header'); ?>
<!-- Add Staff Open -->
<!DOCTYPE html>
<html lang="en">
<body class="no-skin">
<div class="row" style="margin-top: 50px;">
	<div class="col-xs-12">
		<div class="col-md-2"></div>
		<div class="col-md-8 border-tune desh-img">
			<a class="btn btn-info" href="<?php echo site_url('Admin/test_table');?>" class="ace-icon fa fa-check bigger-110">User Details </a>	
			
			<form class="form-horizontal" role="form" enctype="multipart/form-data" method="POST" action="<?php echo site_url('Admin/user_query');?>" >
				<div class="col-md-12 desh-img"><h4>Add User</h4></div>
				<div class="clearfix"></div>	

				<div class="form-group">
					<label class="col-sm-5 control-label no-padding-right" for="form-field-1-1">Name </label>
					<div class="col-sm-7">
						<input type="text" id="form-field-1-1" name="u_name" placeholder="User Name" class="form-control"  />
					</div>
				</div>

				<div class="form-group">
					<label class="col-sm-5 control-label no-padding-right" for="form-field-1-1">Email </label>
					<div class="col-sm-7">
						<input type="email" id="form-field-1-1" name="u_email" placeholder="User Email" class="form-control"  />
					</div>
				</div>
				 
				<!-- <div class="form-group">
					<label class="col-sm-5 control-label no-padding-right" for="form-field-1-1">Email </label>
					<div class="col-sm-7">
						<textarea id="form-field-1-1" name="description" placeholder="Description" class="form-control" /></textarea>
					</div>
				</div> -->

				<div class="form-group">
					<label class="col-sm-5 control-label no-padding-right" for="form-field-1-1">Mobile </label>
					<div class="col-sm-7">
						<input type="text" id="form-field-1-1" name="u_mobile" placeholder="Mobile" class="form-control"  />
					</div>
				</div>

				<div class="form-group">
					<label class="col-sm-5 control-label no-padding-right" for="form-field-1-1">Profile Image </label>
					<div class="col-sm-7">
						<input type="file" name="u_profile" />
						<img src="" style="width: 100px;">
					</div>
				</div>

				<div class="form-group" style="border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; padding-top: 20px; padding-bottom: 20px;">
					<div class="col-sm-5"></div>
					<div class="col-sm-4">
						<div class="input-group">
								<input class="btn btn-info" type="submit" value="Submit" name="squadleader" class="ace-icon fa fa-check bigger-110">
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</form>
	</div>
	<div class="col-md-2"></div>
</div>
<!-- Add Staff close -->
<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
	<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
</a>
</div><!-- /.main-container -->
<script src="<?php echo base_url(); ?>assets/assets/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript">
	if('ontouchstart' in document.documentElement) document.write("<?php echo base_url(); ?>assets/<script src='assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>
<script src="<?php echo base_url(); ?>assets/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/jquery-ui.custom.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/jquery.ui.touch-punch.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/jquery.easypiechart.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/jquery.sparkline.index.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/jquery.flot.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/jquery.flot.pie.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/jquery.flot.resize.min.js"></script>
<!-- ace scripts -->
<script src="assets/js/ace-elements.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/ace.min.js"></script>
<!-- inline scripts related to this page -->
<?php $this->load->view('footer');?>

