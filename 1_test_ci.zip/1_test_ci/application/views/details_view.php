<?php $this->load->view('header'); ?>

			
  <?php foreach($result as $row){ ?>
	<div class="row">
		<div class="col-xs-12">
			<!--PAGE CONTENT BEGINS -->
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="profile-user-info profile-user-info-striped">
					<div class="profile-info-row">
						<div class="profile-info-name"> <th>Name</th> </div>
						<div class="profile-info-value">
							<td><?php echo $row->name; ?></td>
						</div>
					</div>
					<div class="profile-info-row">
						<div class="profile-info-name"> <th><th>Phone</th></th> </div>
						<div class="profile-info-value">
							<td><?php echo $row->mobile; ?></td>
						</div>
					</div>
					<div class="profile-info-row">
						<div class="profile-info-name"> <th><th>email</th></th> </div>
						<div class="profile-info-value">
							<td><?php echo $row->email; ?></td>
						</div>
					</div>
					<div class="profile-info-row">
						<div class="profile-info-name"> <th>Password</th> </div>
						<div class="profile-info-value">
							<td><?php echo $row->password; ?></td>
						</div>
					</div>
					<div class="profile-info-row">
						<div class="profile-info-name"> <th>Description</th> </div>
						<div class="profile-info-value">
							<td><?php echo $row->description; ?></td>
						</div>
					</div>
					
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
		<?php } ?>				
	</div>

<div class="bottom-margin"></div>
<!--[if !IE]> -->
<script src="<?php echo base_url(); ?>assets/assets/js/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/ace-elements.min.js"></script>
<script src="<?php echo base_url(); ?>assets/assets/js/ace.min.js"></script>

<!-- inline scripts related to this page -->
<?php $this->load->view('footer'); ?>


