<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

//--------------------------------------------------Start Login-------------------------------------->
    function userlogin($data)
    {
        $condition = "user =" . "'" . $data['user'] . "' AND " . "pass =" . "'" . $data['pass'] . "'";
        $this->db->select('*');
        $this->db->from('login');
        $this->db->where($condition);
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }
//-------------------------------------------------End Login-------------------------------------->

   
//----------------------for Add Details open------------------------------------//
     
// Delete user Data by id    
    public function delete_details($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('add_details');
    }


/*@@@@@@@@@@@@@@@@@@@ Test open @@@@@@@@@@@@@@@@@@@@@@@@@@*/

function test_query($data){
    $query = $this->db->insert('test',$data);
    return true;
  }
public function update_test($data,$id)
    {
       $this->db->where('id',$id);
      $update = $this->db->update('test',$data);
      return $update;
    }
// Start test Page pagination
    function test_tbl($params = array()){
        $this->db->select('*');
        $this->db->from('test');
        $this->db->order_by("id", "description");
        if(array_key_exists("id",$params)){
            $this->db->where('id',$params['id']);
            $this->db->order_by('id','description');
            $query = $this->db->get();
            $result = $query->row_array();
        }else{
//set start and limit
            if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit'],$params['start']);
            }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit']);
            }
            if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
                $result = $this->db->count_all_results();
            }else{
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }
//return fetched data
        return $result;
    }
// end test Page pagination

// Test fatch data by id
    function test_edit_byid($id)
    {
        $this->db->select();
        $this->db->from('test');
        $this->db->where('id',$id);
        $query = $this->db->get();
        return $query->result();
    }

// update data by id    
    public function test_update($id,$data)
    {   
        $this->db->where('id',$id);
        $this->db->update('test',$data);    
    } 
// Connection for View details_view page    
public function test_view($id)
    {
        $this->db->select();
        $this->db->from('test');
        $this->db->where('id',$id);
        $query = $this->db->get();
        return $query->result();
    }

// Delete user Data by id    
    public function test_delete($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('test');
    }

/////////////////////////////////////view squad Leader///////////////////////////////////////////////////////

/*@@@@@@@@@@@@@@@@@@@ Test open @@@@@@@@@@@@@@@@@@@@@@@@@@*/

function user_query($data){
    $query = $this->db->insert('add_user',$data);
    return true;
  }


// Start test Page pagination
    function user_tbl($params = array()){
        $this->db->select('*');
        $this->db->from('add_user');
        $this->db->order_by("u_id", "u_name");
        if(array_key_exists("u_id",$params)){
            $this->db->where('u_id',$params['u_id']);
            $this->db->order_by('u_id','u_name');
            $query = $this->db->get();
            $result = $query->row_array();
        }else{
//set start and limit
            if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit'],$params['start']);
            }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit']);
            }
            if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
                $result = $this->db->count_all_results();
            }else{
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }
//return fetched data
        return $result;
    }
// end test Page pagination

//------------------------------End  squad leader---------------------->

//------------------------------End Video Stream---------------------->

    
}

