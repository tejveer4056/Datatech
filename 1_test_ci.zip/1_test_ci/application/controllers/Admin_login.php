<?php

class Admin_login extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Login_model');
    
    }

    function index() {
        $this->load->view('index');
    }

    function login_process() {  
   $user = $this->input->post('user');
//$login_date = date('Y/m/d H:i:s');
        
         $_SESSION['user'] =  $user;
        $pass = md5($this->input->post('pass'));
        $result = $this->Login_model->login_process($user,$pass);
        if ($result) {
            if ($user == 0) {
    $this->session->set_userdata('login',true);
                return redirect('Admin/dashboard');
            } if ($role == 1) {
                echo "Welcome Admin";
            }
           
        } else {
            $data['error_msg'] = 'Wrong Username / Password, please try again.';
        }
        $this->load->view('index', $data);
    }


    function logout() {
        $this->load->library('session');
        $this->session->sess_destroy();
        redirect('Admin_login/index');
    }



}
