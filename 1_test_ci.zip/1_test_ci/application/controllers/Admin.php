<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

  function __construct() {
        parent::__construct();
     // $this->load->model("Admin_model");
       $this->load->library('pagination'); // pagination library
       $this->load->model("Admin_model");
	$this->load->library('session');
	$this->load->library('upload');
	$this->load->helper(array('form', 'url'));
    }

	//----------------------for index------------------------------------//
	public function index()
	{
		$this->load->view('index');
	         // $email = $this->input->post('email');
          //$password = $this->input->post('psw');
	}
	//----------------------for Dashboard------------------------------------//
	public function Dashboard()
	{
		$this->load->view('Dashboard');
	}
	
/*@@@@@@@@@@@@@@@@@@@@@@@@ Test Open @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

public function test_add()
	{
		$this->load->view('test_add');
	}
//Method ================> (1)	
	public function test_query()
	{
		$title = $this->input->post("title");
		$description = $this->input->post("description");

		if(!empty($_FILES['image']['name'])){
			$config['upload_path'] = 'uploads';
			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$config['file_name'] = $_FILES['image']['name'];
			$this->load->library('upload',$config);
			$this->upload->initialize($config);
			if($this->upload->do_upload('image')){

				$uploadData = $this->upload->data();
				$image = $uploadData['file_name'];
			}
			else{
				$image = '';
			}
		}
		$data = array( 'title'=>$title, 'description'=>$description, 'image'=>$image);
		$insertUserData = $this->Admin_model->test_query($data); 
		if($insertUserData)
		{
			echo $this->session->set_flashdata('success','Record insert Sucessfully');
			redirect('Admin/test_add'); 
		}
		else
		{

			redirect('Admin/test_add');
		}
	}

//Method ================> (2)
	
/*public function test_query()
	{
	$data = array(
	'title'=> $this->input->post('title'),
	'description'=> $this->input->post('description'),
);
if(!empty($_FILES['image']['name'])){
      $config['upload_path'] = 'uploads';
     $config['allowed_types'] = 'jpg|jpeg|png|gif';
     $config['file_name'] = $_FILES['image']['name'];
        $this->load->library('upload',$config);
        $this->upload->initialize($config);
        if($this->upload->do_upload('image')){
            $uploadData = $this->upload->data();
            $image = $uploadData['file_name'];
        }
     }

	$this->Admin_model->inserttest($data);
	echo "Record insert Successfully";
	header("Location: test_add");
	die();
	}*/


/*===============================================*/	

// Start Details Page pagination tables
function test_table()
    {
        $this->perPage = 5;
        $data = array();
		//get rows count
		$conditions['returnType'] = 'count';
		$totalRec = $this->Admin_model->test_tbl($conditions);
		//pagination config
		$config['base_url']    = base_url().'Admin/test_table/';
		$config['uri_segment'] = 3;
		$config['total_rows']  = $totalRec;
		$config['per_page']    = $this->perPage;
		//styling
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
		$config['cur_tag_close'] = '</a></li>';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$config['next_tag_open'] = '<li class="pg-next">';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li class="pg-prev">';
		$config['prev_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		//initialize pagination library
		$this->pagination->initialize($config);
		//define offset
		$page = $this->uri->segment(3);
		$offset = !$page?0:$page;
		//get rows
		$conditions['returnType'] = '';
		$conditions['start'] = $offset;
		$conditions['limit'] = $this->perPage;
		$data['test_result'] = $this->Admin_model->test_tbl($conditions);
       $this->load->view('test_table',$data);
    }
// end Details Page pagination tables

 // Show or fatch user data by id 
	public function test_edit($id)
	{ 
	$data['result_test'] = $this->Admin_model->test_edit_byid($id);
	$this->load->view('test_edit',$data);
	}

/*Update Test Open*/
//Method ================> (1)
        public function test_update()
        {
          $id=$this->input->post("id");
          $title=$this->input->post("title");
            $description=$this->input->post("description"); 
                  
            if(empty($_FILES['image']['name']))
            {
            $data = array('title' =>$title,'description'=>$description);
            $insertUserData = $this->Admin_model->update_test($data,$id); 
            
            if($insertUserData)
            {
              $this->session->set_flashdata('success','Record Update Sucessfully');
               redirect('Admin/test_table'); 
            }
            else
            {
               //$this->session->set_flashdata('item','Some thing wrong');
              redirect('Admin/test_table');
            }
            }
            else { 
                 $config['upload_path'] = 'uploads';
                   $config['allowed_types'] = 'jpg|jpeg|png|gif';
                   $config['file_name'] = $_FILES['image']['name'];
                    $this->load->library('upload',$config);
                $this->upload->initialize($config);
                if($this->upload->do_upload('image')){
                    $uploadData = $this->upload->data();
                    $image = $uploadData['file_name'];
                }
                $data = array('title' =>$title,'description'=>$description,'image'=>$image);
                $insertUserData = $this->Admin_model->update_test($data,$id); 
                if($insertUserData)
                {
                   $this->session->set_flashdata('success','Record update Sucessfully');
                   redirect('Admin/test_table');
                }
                else
                {
                   //$this->session->set_flashdata('item','Some thing wrong');
                    redirect('Admin/test_table');
                }
            }
        }

//Method =============> (2) 

 /*public function test_update()
        {
        	      	$id=$this->input->post("id");	
        	    	$title = $this->input->post("title");
					$description = $this->input->post("description");
	                  
	             if(empty($_FILES['image']['name']))
	            {
	            $data = array( 'title'=>$title, 'description'=>$description);
	            $insertUserData = $this->Admin_model->inserttest($data,$id); 
	            if($insertUserData)
	            {
	            	$this->session->set_flashdata('success','Record Update Sucessfully');
	               redirect('Admin/test_edit'); 
	            }
	           else
	            {
	               //$this->session->set_flashdata('item','Some thing wrong');
	              redirect('Admin/test_edit');
	            }
	            }
	            else { 
	             $config['upload_path'] = 'uploads';
                 $config['allowed_types'] = 'jpg|jpeg|png|gif';
                 $config['file_name'] = $_FILES['image']['name'];

                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                if($this->upload->do_upload('image')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }
	           $data = array( 'title'=>$title, 'description'=>$description, 'image'=>$image);
	            $insertUserData = $this->Admin_model->inserttest($data,$id); 
	            
	            if($insertUserData)
	            {
	               $this->session->set_flashdata('success','Record update Sucessfully');
	               redirect('Admin/test_edit');
	            }
	           else
	            {
	               //$this->session->set_flashdata('item','Some thing wrong');
	                redirect('Admin/test_edit');
	            }
	        }
        }
*/

/*========================================================*/
public function test_view($id)
	{
           $data['result_test'] = $this->Admin_model->test_view($id);
          $this->load->view('test_view',$data);
	}

// delete user details by id	
public function delete_test($id)
	{
	$this->Admin_model->test_delete($id);
	//echo "Record Deleted";
	redirect('Admin/test_table');
	}


/* @@@@@@@@@@@@@@@@@@@@@@@@@@@@ User Details open @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  */

public function add_user()
	{
		$this->load->view('add_user');
	}

/*--------------------------*/	

public function user_query()
	{
		$u_name = $this->input->post("u_name");
		$u_email = $this->input->post("u_email");
		$u_mobile = $this->input->post("u_mobile");

		if(!empty($_FILES['u_profile']['name'])){
			$config['upload_path'] = 'uploads/user';
			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$config['file_name'] = $_FILES['u_profile']['name'];
			$this->load->library('upload',$config);
			$this->upload->initialize($config);
			if($this->upload->do_upload('u_profile')){

				$uploadData = $this->upload->data();
				$u_profile = $uploadData['file_name'];
			}
			else{
				$u_profile = '';
			}
		}
		$data = array('u_name'=>$u_name, 'u_email'=>$u_email, 'u_mobile'=>$u_mobile, 'u_profile'=>$u_profile);
		$insertUserData = $this->Admin_model->user_query($data); 
		if($insertUserData)
		{
			echo $this->session->set_flashdata('success','Record insert Sucessfully');
			redirect('Admin/add_user'); 
		}
		else
		{
			redirect('Admin/add_user');
		}
	}

/*User Details open*/


// Start Details Page pagination tables
function user_table()
    {
        $this->perPage = 5;
        $data = array();
		//get rows count
		$conditions['returnType'] = 'count';
		$totalRec = $this->Admin_model->user_tbl($conditions);
		//pagination config
		$config['base_url']    = base_url().'Admin/user_table/';
		$config['uri_segment'] = 3;
		$config['total_rows']  = $totalRec;
		$config['per_page']    = $this->perPage;
		//styling
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
		$config['cur_tag_close'] = '</a></li>';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$config['next_tag_open'] = '<li class="pg-next">';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li class="pg-prev">';
		$config['prev_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		//initialize pagination library
		$this->pagination->initialize($config);
		//define offset
		$page = $this->uri->segment(3);
		$offset = !$page?0:$page;
		//get rows
		$conditions['returnType'] = '';
		$conditions['start'] = $offset;
		$conditions['limit'] = $this->perPage;
		$data['user_result'] = $this->Admin_model->user_tbl($conditions);
       $this->load->view('user_table',$data);
    }
// end Details Page pagination tables












}

